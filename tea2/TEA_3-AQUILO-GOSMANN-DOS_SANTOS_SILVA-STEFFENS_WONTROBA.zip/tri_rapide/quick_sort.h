#include <stdio.h>
#include <stdlib.h>

void Tri_rapide( T_elt t[], int begin, int end);