TEA Seance 3

AQUILO Axel
GOSMANN Gabriel
DOS SANTOS SILVA Vitor
STEFFENS WONTROBA Vinícius

Ce rapport met en œuvre et compare la différence de performance des différentes techniques de tri.

