void tri_fusion(T_elt t [], int debut, int fin);
