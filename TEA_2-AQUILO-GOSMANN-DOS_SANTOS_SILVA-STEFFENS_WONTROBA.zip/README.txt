Résolution du jeu "le compte est bon"

AQUILO Axel
GOSMANN Gabriel
DOS SANTOS SILVA Vitor
STEFFENS WONTROBA Vinícius

Le programme en question utilise des techniques de récursivité appliquées 
avec des piles et des listes chaînées pour résoudre le problème proposé
du jeu "le compte est bon".